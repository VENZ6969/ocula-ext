const ALARM_NAME = 'ocula-eye-reminder';

const DEFAULT_SETTINGS = {
  aiProvider: 'gemini',
  apiKey: '',
  geminiApiKey: '',
  aiEnabled: true,
  gymEnabled: true,
  reminderInterval: 20,
  customMinutes: 25
};

// Проверка, является ли страница защищённой страницей браузера
function isRestrictedUrl(url) {
  if (!url) return true;
  if (url.startsWith('chrome://')) return true;
  if (url.startsWith('browser://')) return true;
  if (url.startsWith('edge://')) return true;
  if (url.startsWith('about:')) return true;
  if (url.startsWith('view-source:')) return true;
  if (url.startsWith('devtools://')) return true;
  if (url.startsWith('chrome-extension://')) return true;
  if (url.startsWith('https://chrome.google.com/webstore')) return true;
  if (url.startsWith('https://chromewebstore.google.com')) return true;
  return false;
}

// Чтение настроек из локального хранилища
async function getSettings() {
  const data = await chrome.storage.local.get(Object.keys(DEFAULT_SETTINGS));
  return { ...DEFAULT_SETTINGS, ...data };
}

// Настройка или отключение таймера напоминания о разминке
async function syncReminderAlarm() {
  await chrome.alarms.clear(ALARM_NAME);
  const settings = await getSettings();

  if (!settings.gymEnabled) return;

  const minutes = Number(settings.reminderInterval);
  if (minutes >= 1) {
    await chrome.alarms.create(ALARM_NAME, {
      delayInMinutes: minutes,
      periodInMinutes: minutes
    });
  }
}

// Установка настроек по умолчанию при установке и запуске браузера
chrome.runtime.onInstalled.addListener(async () => {
  const existing = await chrome.storage.local.get(Object.keys(DEFAULT_SETTINGS));
  const merged = { ...DEFAULT_SETTINGS, ...existing };
  await chrome.storage.local.set(merged);
  await syncReminderAlarm();
});

chrome.runtime.onStartup.addListener(async () => {
  await syncReminderAlarm();
});

chrome.storage.onChanged.addListener((changes, areaName) => {
  if (areaName === 'local' && (changes.reminderInterval || changes.gymEnabled)) {
    syncReminderAlarm();
  }
});

// Очистка сохранённых адаптаций при закрытии или обновлении вкладки
chrome.tabs.onRemoved.addListener(async (tabId) => {
  const data = await chrome.storage.local.get('tabStates');
  const tabStates = data.tabStates || {};
  if (tabStates[tabId]) {
    delete tabStates[tabId];
    await chrome.storage.local.set({ tabStates: tabStates });
  }
});

chrome.tabs.onUpdated.addListener(async (tabId, changeInfo) => {
  if (changeInfo.status === 'loading') {
    const data = await chrome.storage.local.get('tabStates');
    const tabStates = data.tabStates || {};
    if (tabStates[tabId]) {
      delete tabStates[tabId];
      await chrome.storage.local.set({ tabStates: tabStates });
    }
  }
});

// Срабатывание таймера напоминания о разминке
chrome.alarms.onAlarm.addListener(async (alarm) => {
  if (alarm.name !== ALARM_NAME) return;

  const settings = await getSettings();
  if (!settings.gymEnabled || Number(settings.reminderInterval) <= 0) return;

  const tabs = await chrome.tabs.query({ active: true, lastFocusedWindow: true });
  const tab = tabs[0];
  if (!tab || !tab.id || isRestrictedUrl(tab.url)) return;

  try {
    await chrome.scripting.executeScript({
      target: { tabId: tab.id },
      func: injectReminderBanner,
      args: [Number(settings.reminderInterval)]
    });
  } catch (err) {
    console.warn('OCULA: не удалось показать напоминание:', err.message);
  }
});

// Перевод бинарного изображения в строку Base64
function arrayBufferToBase64(buffer) {
  const bytes = new Uint8Array(buffer);
  const chunkSize = 0x8000;
  let binary = '';
  for (let i = 0; i < bytes.length; i += chunkSize) {
    binary += String.fromCharCode.apply(null, bytes.subarray(i, i + chunkSize));
  }
  return btoa(binary);
}

// Запрос к выбранной нейросети для описания картинки
async function callAiVision(provider, apiKey, base64Image) {
  const promptText = 'Ты ассистент доступности OCULA. Подробно, ясно и структурированно опиши это изображение на русском языке для человека с нарушением зрения. Укажи главные объекты, действия, цвета, композицию и любой читаемый текст на картинке. Пиши простым языком без лишних вступлений.';

  if (provider === 'gemini') {
    const url = 'https://generativelanguage.googleapis.com/v1beta/models/gemini-2.5-flash:generateContent?key=' + encodeURIComponent(apiKey);
    const response = await fetch(url, {
      method: 'POST',
      headers: { 'Content-Type': 'application/json' },
      body: JSON.stringify({
        contents: [
          {
            parts: [
              { text: promptText },
              {
                inline_data: {
                  mime_type: 'image/jpeg',
                  data: base64Image
                }
              }
            ]
          }
        ],
        generationConfig: { temperature: 0.4, maxOutputTokens: 700 }
      })
    });

    const data = await response.json();
    if (!response.ok) {
      throw new Error((data.error && data.error.message) || 'Ошибка API (' + response.status + ')');
    }
    const text = data.candidates && data.candidates[0] && data.candidates[0].content && data.candidates[0].content.parts[0].text;
    if (!text) throw new Error('Нейросеть не вернула описание изображения.');
    return text.trim();
  }

  // Настройки для OpenAI, Kimi и DeepSeek (формат chat/completions)
  let endpoint = '';
  let modelName = '';

  if (provider === 'openai') {
    endpoint = 'https://api.openai.com/v1/chat/completions';
    modelName = 'gpt-4o-mini';
  } else if (provider === 'kimi') {
    endpoint = 'https://api.moonshot.cn/v1/chat/completions';
    modelName = 'moonshot-v1-8k-vision-preview';
  } else if (provider === 'deepseek') {
    endpoint = 'https://api.deepseek.com/chat/completions';
    modelName = 'deepseek-chat';
  } else {
    throw new Error('Выбрана неизвестная нейросеть.');
  }

  const response = await fetch(endpoint, {
    method: 'POST',
    headers: {
      'Content-Type': 'application/json',
      'Authorization': 'Bearer ' + apiKey
    },
    body: JSON.stringify({
      model: modelName,
      messages: [
        {
          role: 'user',
          content: [
            { type: 'text', text: promptText },
            {
              type: 'image_url',
              image_url: { url: 'data:image/jpeg;base64,' + base64Image }
            }
          ]
        }
      ],
      temperature: 0.4,
      max_tokens: 700
    })
  });

  const data = await response.json();
  if (!response.ok) {
    throw new Error((data.error && data.error.message) || 'Ошибка API (' + response.status + ')');
  }

  const text = data.choices && data.choices[0] && data.choices[0].message && data.choices[0].message.content;
  if (!text) throw new Error('Нейросеть не вернула описание изображения.');
  return text.trim();
}

// Обработка сообщений от окна расширения и скриптов на странице
chrome.runtime.onMessage.addListener((message, sender, sendResponse) => {
  if (message.type === 'SYNC_ALARM') {
    syncReminderAlarm().then(() => sendResponse({ ok: true }));
    return true;
  }

  if (message.type === 'LAUNCH_GYM_FROM_REMINDER' && sender.tab && sender.tab.id) {
    chrome.scripting.executeScript({
      target: { tabId: sender.tab.id },
      files: ['gym.js']
    }).then(() => sendResponse({ ok: true })).catch(err => sendResponse({ ok: false, error: err.message }));
    return true;
  }

  if (message.type === 'START_IMAGE_PICKER') {
    chrome.scripting.executeScript({
      target: { tabId: message.tabId },
      func: injectImagePickerOnPage
    }).then(() => sendResponse({ ok: true })).catch(err => sendResponse({ ok: false, error: err.message }));
    return true;
  }

  if (message.type === 'DESCRIBE_IMAGE_AREA' && sender.tab && sender.tab.id) {
    handleImageDescription(sender.tab, message).then(sendResponse);
    return true;
  }
});

// Снимок области экрана, обрезка по координатам картинки и отправка нейросети
async function handleImageDescription(tab, message) {
  try {
    const settings = await getSettings();
    const apiKey = (settings.apiKey || settings.geminiApiKey || '').trim();
    const provider = settings.aiProvider || 'gemini';

    if (!settings.aiEnabled) {
      throw new Error('Модуль ИИ отключён в настройках.');
    }
    if (!apiKey) {
      throw new Error('Не указан API-ключ. Добавьте его во вкладке «Настройки».');
    }

    const dataUrl = await chrome.tabs.captureVisibleTab(tab.windowId, { format: 'png' });
    const imgResp = await fetch(dataUrl);
    const fullBlob = await imgResp.blob();
    const bitmap = await createImageBitmap(fullBlob);

    const scaleX = bitmap.width / message.viewport.width;
    const scaleY = bitmap.height / message.viewport.height;

    const sx = Math.max(0, Math.round(message.rect.left * scaleX));
    const sy = Math.max(0, Math.round(message.rect.top * scaleY));
    const sw = Math.min(bitmap.width - sx, Math.max(1, Math.round(message.rect.width * scaleX)));
    const sh = Math.min(bitmap.height - sy, Math.max(1, Math.round(message.rect.height * scaleY)));

    const maxDim = 1280;
    const ratio = Math.min(1, maxDim / Math.max(sw, sh));
    const outW = Math.max(1, Math.round(sw * ratio));
    const outH = Math.max(1, Math.round(sh * ratio));

    const canvas = new OffscreenCanvas(outW, outH);
    const ctx = canvas.getContext('2d');
    ctx.drawImage(bitmap, sx, sy, sw, sh, 0, 0, outW, outH);
    bitmap.close();

    const croppedBlob = await canvas.convertToBlob({ type: 'image/jpeg', quality: 0.85 });
    const buffer = await croppedBlob.arrayBuffer();
    const base64 = arrayBufferToBase64(buffer);

    const description = await callAiVision(provider, apiKey, base64);

    await chrome.storage.local.set({
      lastAiResult: {
        title: 'Описание изображения',
        text: description,
        timestamp: Date.now()
      }
    });

    await chrome.scripting.executeScript({
      target: { tabId: tab.id },
      func: showImageDescriptionResultOnPage,
      args: [description, null]
    });

    return { ok: true, description: description };
  } catch (err) {
    await chrome.scripting.executeScript({
      target: { tabId: tab.id },
      func: showImageDescriptionResultOnPage,
      args: [null, err.message]
    }).catch(() => {});
    return { ok: false, error: err.message };
  }
}

// Показ окна напоминания о разминке поверх сайта
function injectReminderBanner(intervalMinutes) {
  const existing = document.getElementById('ocula-reminder-toast');
  if (existing) existing.remove();

  const toast = document.createElement('div');
  toast.id = 'ocula-reminder-toast';
  toast.setAttribute('role', 'dialog');
  toast.setAttribute('aria-label', 'Напоминание о разминке для глаз');
  toast.style.cssText = 'position:fixed;bottom:24px;right:24px;width:340px;background:#0b0f19;color:#f8fafc;border:2px solid #38bdf8;border-radius:14px;padding:18px;z-index:2147483646;font-family:-apple-system,BlinkMacSystemFont,"Segoe UI",Roboto,sans-serif;box-shadow:0 20px 45px rgba(0,0,0,0.6);';

  toast.innerHTML =
    '<div style="display:flex;justify-content:space-between;align-items:center;margin-bottom:8px;">' +
      '<span style="font-size:13px;font-weight:800;letter-spacing:0.6px;color:#38bdf8;">OCULA • ЗАБОТА О ЗРЕНИИ</span>' +
      '<button id="ocula-rem-close" style="background:transparent;border:none;color:#94a3b8;font-size:18px;cursor:pointer;padding:2px 6px;" title="Закрыть">✕</button>' +
    '</div>' +
    '<div style="font-size:15px;font-weight:700;margin-bottom:6px;">Пора сделать паузу для глаз</div>' +
    '<div style="font-size:13px;color:#cbd5e1;line-height:1.45;margin-bottom:14px;">Прошло ' + intervalMinutes + ' мин. Короткая разминка по Аветисову и правилу «20-20-20» снимет напряжение.</div>' +
    '<div style="display:flex;gap:8px;">' +
      '<button id="ocula-rem-start" style="flex:1;background:#38bdf8;color:#082f49;border:none;border-radius:8px;padding:10px 12px;font-size:13px;font-weight:800;cursor:pointer;">👁️ Начать разминку</button>' +
      '<button id="ocula-rem-later" style="background:#1b2438;color:#f8fafc;border:1px solid #334155;border-radius:8px;padding:10px 12px;font-size:13px;font-weight:600;cursor:pointer;">Позже</button>' +
    '</div>';

  document.body.appendChild(toast);

  function removeToast() {
    toast.remove();
  }

  toast.querySelector('#ocula-rem-close').addEventListener('click', removeToast);
  toast.querySelector('#ocula-rem-later').addEventListener('click', removeToast);
  toast.querySelector('#ocula-rem-start').addEventListener('click', () => {
    removeToast();
    chrome.runtime.sendMessage({ type: 'LAUNCH_GYM_FROM_REMINDER' });
  });
}

// Режим выбора картинки на странице мышкой
function injectImagePickerOnPage() {
  if (window.__oculaPickerActive) return;
  window.__oculaPickerActive = true;

  const oldOverlay = document.getElementById('ocula-ai-result-overlay');
  if (oldOverlay) oldOverlay.remove();

  const banner = document.createElement('div');
  banner.id = 'ocula-picker-banner';
  banner.style.cssText = 'position:fixed;top:16px;left:50%;transform:translateX(-50%);background:#0b0f19;color:#f8fafc;border:2px solid #38bdf8;border-radius:12px;padding:12px 18px;z-index:2147483647;font-family:-apple-system,BlinkMacSystemFont,"Segoe UI",Roboto,sans-serif;font-size:14px;font-weight:600;display:flex;align-items:center;gap:14px;box-shadow:0 12px 30px rgba(0,0,0,0.55);';
  banner.innerHTML =
    '<span>🖼️ Наведите на любую картинку и кликните для ИИ-описания</span>' +
    '<button id="ocula-picker-cancel" style="background:#1b2438;color:#f8fafc;border:1px solid #38bdf8;border-radius:6px;padding:5px 10px;font-size:12px;font-weight:700;cursor:pointer;">Отмена (Esc)</button>';

  const highlightBox = document.createElement('div');
  highlightBox.id = 'ocula-picker-highlight';
  highlightBox.style.cssText = 'position:fixed;pointer-events:none;border:3px solid #38bdf8;background:rgba(56,189,248,0.16);border-radius:6px;z-index:2147483646;display:none;box-sizing:border-box;';

  document.body.appendChild(highlightBox);
  document.body.appendChild(banner);

  let currentTarget = null;

  function findVisualTarget(el) {
    if (!el || banner.contains(el)) return null;
    const candidate = el.closest('img, svg, canvas, video, [role="img"]');
    if (candidate) return candidate;
    return el.tagName === 'IMG' ? el : null;
  }

  function cleanupPicker() {
    window.__oculaPickerActive = false;
    document.removeEventListener('mousemove', onMouseMove, true);
    document.removeEventListener('click', onClick, true);
    document.removeEventListener('keydown', onKeyDown, true);
    banner.remove();
    highlightBox.remove();
  }

  function onMouseMove(e) {
    const target = findVisualTarget(e.target);
    if (!target) {
      currentTarget = null;
      highlightBox.style.display = 'none';
      return;
    }
    const rect = target.getBoundingClientRect();
    if (rect.width < 12 || rect.height < 12) {
      currentTarget = null;
      highlightBox.style.display = 'none';
      return;
    }
    currentTarget = target;
    highlightBox.style.display = 'block';
    highlightBox.style.left = rect.left + 'px';
    highlightBox.style.top = rect.top + 'px';
    highlightBox.style.width = rect.width + 'px';
    highlightBox.style.height = rect.height + 'px';
  }

  function onKeyDown(e) {
    if (e.key === 'Escape') cleanupPicker();
  }

  function showLoadingModal() {
    const modal = document.createElement('div');
    modal.id = 'ocula-ai-result-overlay';
    modal.style.cssText = 'position:fixed;bottom:24px;right:24px;width:370px;max-width:calc(100vw - 32px);background:#0b0f19;color:#f8fafc;border:2px solid #38bdf8;border-radius:14px;padding:18px;z-index:2147483647;font-family:-apple-system,BlinkMacSystemFont,"Segoe UI",Roboto,sans-serif;box-shadow:0 20px 50px rgba(0,0,0,0.7);';
    modal.innerHTML =
      '<div style="font-size:13px;font-weight:800;color:#38bdf8;margin-bottom:8px;">OCULA • ИИ-АНАЛИЗ ИЗОБРАЖЕНИЯ</div>' +
      '<div style="font-size:14px;color:#cbd5e1;">Делаем снимок области и отправляем нейросети...</div>';
    document.body.appendChild(modal);
  }

  function onClick(e) {
    if (banner.contains(e.target)) return;
    const target = findVisualTarget(e.target) || currentTarget;
    if (!target) return;

    e.preventDefault();
    e.stopPropagation();

    const rect = target.getBoundingClientRect();
    cleanupPicker();

    if (rect.width < 10 || rect.height < 10) return;

    requestAnimationFrame(() => {
      requestAnimationFrame(() => {
        showLoadingModal();
        chrome.runtime.sendMessage({
          type: 'DESCRIBE_IMAGE_AREA',
          rect: { left: rect.left, top: rect.top, width: rect.width, height: rect.height },
          viewport: { width: window.innerWidth, height: window.innerHeight }
        });
      });
    });
  }

  banner.querySelector('#ocula-picker-cancel').addEventListener('click', cleanupPicker);
  document.addEventListener('mousemove', onMouseMove, true);
  document.addEventListener('click', onClick, true);
  document.addEventListener('keydown', onKeyDown, true);
}

// Вывод результата описания картинки прямо на странице
function showImageDescriptionResultOnPage(description, errorMsg) {
  let modal = document.getElementById('ocula-ai-result-overlay');
  if (!modal) {
    modal = document.createElement('div');
    modal.id = 'ocula-ai-result-overlay';
    modal.style.cssText = 'position:fixed;bottom:24px;right:24px;width:390px;max-width:calc(100vw - 32px);background:#0b0f19;color:#f8fafc;border:2px solid #38bdf8;border-radius:14px;padding:18px;z-index:2147483647;font-family:-apple-system,BlinkMacSystemFont,"Segoe UI",Roboto,sans-serif;box-shadow:0 20px 50px rgba(0,0,0,0.75);';
    document.body.appendChild(modal);
  }

  if (errorMsg) {
    modal.innerHTML =
      '<div style="display:flex;justify-content:space-between;align-items:center;margin-bottom:10px;">' +
        '<span style="font-size:13px;font-weight:800;color:#f87171;">OCULA • ОШИБКА</span>' +
        '<button id="ocula-res-close" style="background:transparent;border:none;color:#94a3b8;font-size:18px;cursor:pointer;">✕</button>' +
      '</div>' +
      '<div id="ocula-res-err" style="font-size:14px;line-height:1.5;color:#fecaca;"></div>';
    modal.querySelector('#ocula-res-err').textContent = errorMsg;
    modal.querySelector('#ocula-res-close').addEventListener('click', () => {
      window.speechSynthesis.cancel();
      modal.remove();
    });
    return;
  }

  modal.innerHTML =
    '<div style="display:flex;justify-content:space-between;align-items:center;margin-bottom:10px;">' +
      '<span style="font-size:13px;font-weight:800;color:#38bdf8;">OCULA • ОПИСАНИЕ КАРТИНКИ</span>' +
      '<button id="ocula-res-close" style="background:transparent;border:none;color:#94a3b8;font-size:18px;cursor:pointer;">✕</button>' +
    '</div>' +
    '<div id="ocula-res-body" style="font-size:14px;line-height:1.55;color:#f1f5f9;max-height:240px;overflow-y:auto;margin-bottom:14px;white-space:pre-wrap;"></div>' +
    '<div style="display:flex;gap:8px;">' +
      '<button id="ocula-res-speak" style="flex:1;background:#38bdf8;color:#082f49;border:none;border-radius:8px;padding:9px 12px;font-size:13px;font-weight:800;cursor:pointer;">🔊 Озвучить</button>' +
      '<button id="ocula-res-stop" style="background:#1b2438;color:#f8fafc;border:1px solid #334155;border-radius:8px;padding:9px 12px;font-size:13px;font-weight:600;cursor:pointer;">⏹️ Стоп</button>' +
    '</div>';

  modal.querySelector('#ocula-res-body').textContent = description;

  modal.querySelector('#ocula-res-speak').addEventListener('click', () => {
    window.speechSynthesis.cancel();
    const ut = new SpeechSynthesisUtterance(description);
    ut.lang = 'ru-RU';
    window.speechSynthesis.speak(ut);
  });

  modal.querySelector('#ocula-res-stop').addEventListener('click', () => {
    window.speechSynthesis.cancel();
  });

  modal.querySelector('#ocula-res-close').addEventListener('click', () => {
    window.speechSynthesis.cancel();
    modal.remove();
  });
}