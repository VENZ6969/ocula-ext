// Начальные настройки адаптации для каждой вкладки
const DEFAULT_PAGE_STATE = {
  zoom: 100,
  spacePercent: 100,
  dyslexic: false,
  contrastValue: 100,
  brightnessValue: 100,
  blurValue: 0,
  invert: false,
  cataract: false,
  night: false,
  colorMode: 'none',
  cursor: false,
  links: false,
  hideimg: false,
  audio: false
};

let state = { ...DEFAULT_PAGE_STATE };
let activeTab = null;
let isRestricted = false;
let currentAiResultText = '';

// Проверка, является ли страница служебной страницей браузера
function isRestrictedUrl(url) {
  if (!url) return true;
  if (url.startsWith('chrome://')) return true;
  if (url.startsWith('browser://')) return true;
  if (url.startsWith('edge://')) return true;
  if (url.startsWith('about:')) return true;
  if (url.startsWith('view-source:')) return true;
  if (url.startsWith('devtools://')) return true;
  if (url.startsWith('chrome-extension://')) return true;
  if (url.startsWith('https://chrome.google.com/webstore')) return true;
  if (url.startsWith('https://chromewebstore.google.com')) return true;
  return false;
}

// Запуск функции внутри активной вкладки
async function runOnTab(func, args) {
  if (isRestricted || !activeTab || !activeTab.id) return null;
  const list = args || [];
  const results = await chrome.scripting.executeScript({
    target: { tabId: activeTab.id },
    func: func,
    args: list
  });
  if (results && results[0]) {
    return results[0].result;
  }
  return null;
}

// Сохранение текущего состояния адаптации для активной вкладки
async function saveTabState() {
  if (!activeTab || !activeTab.id || isRestricted) return;
  const data = await chrome.storage.local.get('tabStates');
  const tabStates = data.tabStates || {};
  tabStates[activeTab.id] = { ...state };
  await chrome.storage.local.set({ tabStates: tabStates });
}

// =========================================================
// ФУНКЦИИ АДАПТАЦИИ СТРАНИЦЫ (внедряются на сайт)
// =========================================================

function applyZoomSetting(zoomValue) {
  if (zoomValue === 100) {
    document.documentElement.style.removeProperty('zoom');
  } else {
    document.documentElement.style.setProperty('zoom', zoomValue + '%', 'important');
  }
}

function applyTextSettings(spacePercent, isDyslexic) {
  let styleEl = document.getElementById('helper-text-styles');
  if (!styleEl) {
    styleEl = document.createElement('style');
    styleEl.id = 'helper-text-styles';
    document.head.appendChild(styleEl);
  }
  let cssRules = '';
  if (spacePercent > 100) {
    const lineHeight = (spacePercent / 100).toFixed(2);
    cssRules += 'p, span, li, a, h1, h2, h3 { line-height: ' + lineHeight + ' !important; letter-spacing: 1px !important; } ';
  }
  if (isDyslexic) {
    cssRules += "* { font-family: 'Comic Sans MS', 'Arial Black', sans-serif !important; } ";
  }
  styleEl.textContent = cssRules;
}

function applyVisualFilters(cVal, bVal, blurVal, mode) {
  let filterEl = document.getElementById('helper-filter-styles');
  if (!filterEl) {
    filterEl = document.createElement('style');
    filterEl.id = 'helper-filter-styles';
    document.head.appendChild(filterEl);
  }

  let filters = '';
  if (cVal !== 100 || bVal !== 100 || mode !== 'none') {
    filters = 'contrast(' + cVal + '%) brightness(' + bVal + '%) ';
    if (mode === 'invert') filters += 'grayscale(1) invert(1) ';
    else if (mode === 'night') filters += 'sepia(0.6) saturate(1.3) hue-rotate(-10deg) ';
    else if (mode === 'prot') filters += 'hue-rotate(90deg) saturate(1.2) ';
    else if (mode === 'deut') filters += 'hue-rotate(180deg) saturate(1.2) ';
    else if (mode === 'trit') filters += 'hue-rotate(270deg) saturate(1.4) ';
  }

  filterEl.textContent = filters ? 'html { filter: ' + filters + ' !important; }' : '';

  let blurEl = document.getElementById('helper-blur-styles');
  if (!blurEl) {
    blurEl = document.createElement('style');
    blurEl.id = 'helper-blur-styles';
    document.head.appendChild(blurEl);
  }
  blurEl.textContent = blurVal > 0 ? 'img, video { filter: blur(' + blurVal + 'px) !important; }' : '';
}

function toggleCataractMode(isActive) {
  let catEl = document.getElementById('helper-cataract-styles');
  if (!catEl) {
    catEl = document.createElement('style');
    catEl.id = 'helper-cataract-styles';
    document.head.appendChild(catEl);
  }
  if (isActive) {
    catEl.textContent = 'html, body, div, p, span, li, a, h1, h2, h3 { background-color: #000000 !important; color: #ffff00 !important; border-color: #ffff00 !important; } img, video { opacity: 0.2; }';
  } else {
    catEl.textContent = '';
  }
}

function toggleBigCursor(isActive) {
  let curEl = document.getElementById('helper-cursor-styles');
  if (!curEl) {
    curEl = document.createElement('style');
    curEl.id = 'helper-cursor-styles';
    document.head.appendChild(curEl);
  }
  const svgCursor = encodeURIComponent(
    '<svg xmlns="http://www.w3.org/2000/svg" width="48" height="48" viewBox="0 0 24 24"><path d="M4 2l16 11-6.5 1.5 4.5 6.5-3 2-4.5-6.5-2.5 4.5v-19z" fill="black" stroke="white" stroke-width="2"/></svg>'
  );
  curEl.textContent = isActive ? '* { cursor: url("data:image/svg+xml,' + svgCursor + '"), auto !important; }' : '';
}

function toggleLinksHighlight(isActive) {
  let linkEl = document.getElementById('helper-links-styles');
  if (!linkEl) {
    linkEl = document.createElement('style');
    linkEl.id = 'helper-links-styles';
    document.head.appendChild(linkEl);
  }
  linkEl.textContent = isActive
    ? 'a { background-color: #ffff00 !important; color: #000000 !important; font-weight: bold !important; border: 2px dashed #000 !important; }'
    : '';
}

function toggleHideImages(isActive) {
  let imgEl = document.getElementById('helper-img-styles');
  if (!imgEl) {
    imgEl = document.createElement('style');
    imgEl.id = 'helper-img-styles';
    document.head.appendChild(imgEl);
  }
  imgEl.textContent = isActive
    ? 'img, svg, video, [style*="background-image"] { visibility: hidden !important; }'
    : '';
}

function toggleAudioReader(isActive) {
  if (isActive) {
    if (window.hasAudioReaderAttached) return;
    window.hasAudioReaderAttached = true;
    window.audioClickHandler = function (e) {
      if (e.target.closest('#ocula-eye-gym, #ocula-ai-result-overlay, #ocula-reminder-toast')) return;
      const text = e.target.innerText || e.target.textContent;
      if (text && text.trim().length > 0) {
        e.preventDefault();
        e.stopPropagation();
        window.speechSynthesis.cancel();
        const ut = new SpeechSynthesisUtterance(text.trim());
        ut.lang = 'ru-RU';
        window.speechSynthesis.speak(ut);
      }
    };
    document.addEventListener('click', window.audioClickHandler, true);
  } else {
    if (window.audioClickHandler) {
      document.removeEventListener('click', window.audioClickHandler, true);
      window.audioClickHandler = null;
    }
    window.hasAudioReaderAttached = false;
    window.speechSynthesis.cancel();
  }
}

function resetAllPageAdaptations() {
  document.documentElement.style.removeProperty('zoom');
  const styleIds = [
    'helper-text-styles',
    'helper-filter-styles',
    'helper-blur-styles',
    'helper-cataract-styles',
    'helper-cursor-styles',
    'helper-links-styles',
    'helper-img-styles'
  ];
  for (let i = 0; i < styleIds.length; i++) {
    const el = document.getElementById(styleIds[i]);
    if (el) el.remove();
  }
  if (window.audioClickHandler) {
    document.removeEventListener('click', window.audioClickHandler, true);
    window.audioClickHandler = null;
  }
  window.hasAudioReaderAttached = false;
  if ('speechSynthesis' in window) {
    window.speechSynthesis.cancel();
  }
}

function getSelectedTextOnPage() {
  if (window.getSelection) {
    return window.getSelection().toString().trim();
  }
  return '';
}

// =========================================================
// УПРАВЛЕНИЕ ВКЛАДКАМИ И СКОЛЬЗЯЩИМ ИНДИКАТОРОМ
// =========================================================

function moveTabIndicator(activeBtn) {
  const indicator = document.getElementById('tab-indicator');
  if (!indicator || !activeBtn) return;
  indicator.style.width = activeBtn.offsetWidth + 'px';
  indicator.style.transform = 'translateX(' + activeBtn.offsetLeft + 'px)';
}

function switchTab(tabKey) {
  const buttons = document.querySelectorAll('.tab-btn');
  for (let i = 0; i < buttons.length; i++) {
    const btn = buttons[i];
    const isActive = btn.dataset.tab === tabKey;
    btn.classList.toggle('active', isActive);
    if (isActive) {
      moveTabIndicator(btn);
    }
  }

  const panes = document.querySelectorAll('.tab-pane');
  for (let i = 0; i < panes.length; i++) {
    panes[i].classList.toggle('active', panes[i].id === 'tab-' + tabKey);
  }
}

// =========================================================
// ОБНОВЛЕНИЕ ИНТЕРФЕЙСА ПОПАПА
// =========================================================

function setToggleButtonState(id, isActive) {
  const btn = document.getElementById(id);
  if (!btn) return;
  btn.classList.toggle('active', Boolean(isActive));
  const pill = btn.querySelector('.status-pill');
  if (pill) {
    pill.textContent = isActive ? 'ВКЛ' : 'ВЫКЛ';
  }
}

function syncUiFromState() {
  document.getElementById('slider-zoom').value = state.zoom;
  document.getElementById('val-zoom').textContent = state.zoom + '%';

  document.getElementById('slider-space').value = state.spacePercent;
  document.getElementById('val-space').textContent = state.spacePercent === 100 ? 'Норма' : state.spacePercent + '%';

  document.getElementById('slider-contrast').value = state.contrastValue;
  document.getElementById('val-contrast').textContent = state.contrastValue + '%';

  document.getElementById('slider-brightness').value = state.brightnessValue;
  document.getElementById('val-brightness').textContent = state.brightnessValue + '%';

  document.getElementById('slider-blur').value = state.blurValue;
  document.getElementById('val-blur').textContent = state.blurValue + ' px';

  setToggleButtonState('btn-dys', state.dyslexic);
  setToggleButtonState('btn-links', state.links);
  setToggleButtonState('btn-cursor', state.cursor);
  setToggleButtonState('btn-audio', state.audio);
  setToggleButtonState('btn-invert', state.invert);
  setToggleButtonState('btn-cataract', state.cataract);
  setToggleButtonState('btn-night', state.night);
  setToggleButtonState('btn-hideimg', state.hideimg);

  const modes = ['prot', 'deut', 'trit'];
  for (let i = 0; i < modes.length; i++) {
    const mode = modes[i];
    document.getElementById('btn-' + mode).classList.toggle('active', state.colorMode === mode);
  }
}

function setPageControlsDisabled(disabled) {
  const selectors = [
    '#tab-text button',
    '#tab-text input',
    '#tab-screen button',
    '#tab-screen input',
    '#btn-reset',
    '#btn-ai-summary',
    '#btn-ai-image',
    '#btn-gym'
  ];
  for (let i = 0; i < selectors.length; i++) {
    const items = document.querySelectorAll(selectors[i]);
    for (let j = 0; j < items.length; j++) {
      items[j].disabled = disabled;
    }
  }
}

function updateText() {
  runOnTab(applyTextSettings, [state.spacePercent, state.dyslexic]);
  saveTabState();
}

function updateFilters() {
  let activeMode = state.colorMode;
  if (state.invert) activeMode = 'invert';
  else if (state.night) activeMode = 'night';

  runOnTab(applyVisualFilters, [state.contrastValue, state.brightnessValue, state.blurValue, activeMode]);
  saveTabState();
}

function resetColorFilters() {
  state.invert = false;
  state.night = false;
  state.colorMode = 'none';
  setToggleButtonState('btn-invert', false);
  setToggleButtonState('btn-night', false);
  document.getElementById('btn-prot').classList.remove('active');
  document.getElementById('btn-deut').classList.remove('active');
  document.getElementById('btn-trit').classList.remove('active');
}

// =========================================================
// ИИ-ПОМОЩНИК (ПОДДЕРЖКА GEMINI, OPENAI, KIMI, DEEPSEEK)
// =========================================================

function setAiStatus(text, isError) {
  const el = document.getElementById('ai-status');
  if (!text) {
    el.classList.add('hidden');
    el.textContent = '';
    return;
  }
  el.textContent = text;
  el.classList.toggle('error', Boolean(isError));
  el.classList.remove('hidden');
}

function showAiResult(title, text) {
  currentAiResultText = text;
  document.getElementById('ai-result-title').textContent = title;
  document.getElementById('ai-result-text').textContent = text;
  document.getElementById('ai-result-card').classList.remove('hidden');
}

// Запрос к выбранной нейросети для анализа текста
async function askAiForSummary(provider, apiKey, promptText) {
  if (provider === 'gemini') {
    const url = 'https://generativelanguage.googleapis.com/v1beta/models/gemini-2.5-flash:generateContent?key=' + encodeURIComponent(apiKey);
    const response = await fetch(url, {
      method: 'POST',
      headers: { 'Content-Type': 'application/json' },
      body: JSON.stringify({
        contents: [{ parts: [{ text: promptText }] }],
        generationConfig: { temperature: 0.35, maxOutputTokens: 700 }
      })
    });
    const data = await response.json();
    if (!response.ok) {
      throw new Error((data.error && data.error.message) || 'Ошибка API (' + response.status + ')');
    }
    const answer = data.candidates && data.candidates[0] && data.candidates[0].content && data.candidates[0].content.parts[0].text;
    if (!answer) throw new Error('Нейросеть не вернула текст.');
    return answer.trim();
  }

  // Настройки для провайдеров со стандартным форматом chat/completions
  let endpoint = '';
  let modelName = '';

  if (provider === 'openai') {
    endpoint = 'https://api.openai.com/v1/chat/completions';
    modelName = 'gpt-4o-mini';
  } else if (provider === 'kimi') {
    endpoint = 'https://api.moonshot.cn/v1/chat/completions';
    modelName = 'moonshot-v1-8k';
  } else if (provider === 'deepseek') {
    endpoint = 'https://api.deepseek.com/chat/completions';
    modelName = 'deepseek-chat';
  } else {
    throw new Error('Выбрана неизвестная нейросеть.');
  }

  const response = await fetch(endpoint, {
    method: 'POST',
    headers: {
      'Content-Type': 'application/json',
      'Authorization': 'Bearer ' + apiKey
    },
    body: JSON.stringify({
      model: modelName,
      messages: [{ role: 'user', content: promptText }],
      temperature: 0.35,
      max_tokens: 700
    })
  });

  const data = await response.json();
  if (!response.ok) {
    throw new Error((data.error && data.error.message) || 'Ошибка API (' + response.status + ')');
  }

  const answer = data.choices && data.choices[0] && data.choices[0].message && data.choices[0].message.content;
  if (!answer) throw new Error('Нейросеть не вернула текст.');
  return answer.trim();
}

async function summarizeSelectedText() {
  if (isRestricted) return;
  setAiStatus('', false);

  const settings = await chrome.storage.local.get(['aiProvider', 'apiKey', 'geminiApiKey', 'aiEnabled']);
  const aiEnabled = settings.aiEnabled !== false;
  const provider = settings.aiProvider || 'gemini';
  const apiKey = (settings.apiKey || settings.geminiApiKey || '').trim();

  if (!aiEnabled) {
    setAiStatus('Модуль ИИ отключён в настройках.', true);
    return;
  }
  if (!apiKey) {
    setAiStatus('Сначала выберите нейросеть и укажите API-ключ в настройках.', true);
    return;
  }

  const selectedText = await runOnTab(getSelectedTextOnPage);
  if (!selectedText) {
    setAiStatus('Выделите фрагмент текста на странице и повторите попытку.', true);
    return;
  }

  const btn = document.getElementById('btn-ai-summary');
  btn.disabled = true;
  setAiStatus('Нейросеть анализирует выделенный текст...', false);

  try {
    const prompt = 'Сделай краткую, понятную и структурированную выжимку следующего текста на русском языке простыми словами. Выдели главную мысль и 3–5 ключевых тезисов списком без воды:\n\n' + selectedText.slice(0, 12000);
    const answer = await askAiForSummary(provider, apiKey, prompt);

    setAiStatus('', false);
    showAiResult('Суть выделенного текста', answer);
    await chrome.storage.local.set({
      lastAiResult: { title: 'Суть выделенного текста', text: answer, timestamp: Date.now() }
    });
  } catch (err) {
    setAiStatus('Ошибка: ' + err.message, true);
  } finally {
    btn.disabled = isRestricted;
  }
}

async function startImageDescriptionFlow() {
  if (isRestricted || !activeTab || !activeTab.id) return;

  const settings = await chrome.storage.local.get(['apiKey', 'geminiApiKey', 'aiEnabled']);
  const aiEnabled = settings.aiEnabled !== false;
  const apiKey = (settings.apiKey || settings.geminiApiKey || '').trim();

  if (!aiEnabled) {
    setAiStatus('Модуль ИИ отключён в настройках.', true);
    return;
  }
  if (!apiKey) {
    setAiStatus('Сначала выберите нейросеть и укажите API-ключ в настройках.', true);
    return;
  }

  await chrome.runtime.sendMessage({ type: 'START_IMAGE_PICKER', tabId: activeTab.id });
  window.close();
}

// =========================================================
// ЗАГРУЗКА НАСТРОЕК
// =========================================================

async function loadAndRenderSettings() {
  const data = await chrome.storage.local.get([
    'aiProvider',
    'apiKey',
    'geminiApiKey',
    'aiEnabled',
    'gymEnabled',
    'reminderInterval',
    'customMinutes',
    'lastAiResult'
  ]);

  const aiProvider = data.aiProvider || 'gemini';
  const apiKey = data.apiKey || data.geminiApiKey || '';
  const aiEnabled = data.aiEnabled !== false;
  const gymEnabled = data.gymEnabled !== false;
  const reminderInterval = data.reminderInterval !== undefined ? data.reminderInterval : 20;
  const customMinutes = data.customMinutes || 25;

  document.getElementById('toggle-ai-enabled').checked = aiEnabled;
  document.getElementById('toggle-gym-enabled').checked = gymEnabled;
  document.getElementById('select-ai-provider').value = aiProvider;
  document.getElementById('input-api-key').value = apiKey;
  document.getElementById('input-custom-minutes').value = customMinutes;

  const presetValues = ['0', '20', '30', '45', '60'];
  const strInterval = String(reminderInterval);
  const selectEl = document.getElementById('select-reminder');
  const customWrap = document.getElementById('custom-interval-wrap');

  if (presetValues.includes(strInterval)) {
    selectEl.value = strInterval;
    customWrap.classList.add('hidden');
  } else {
    selectEl.value = 'custom';
    document.getElementById('input-custom-minutes').value = reminderInterval;
    customWrap.classList.remove('hidden');
  }

  document.getElementById('module-ai').classList.toggle('hidden', !aiEnabled);
  document.getElementById('ai-disabled-notice').classList.toggle('hidden', aiEnabled);
  document.getElementById('ai-no-key-notice').classList.toggle('hidden', Boolean(apiKey.trim()));

  document.getElementById('module-gym').classList.toggle('hidden', !gymEnabled);
  document.getElementById('gym-disabled-notice').classList.toggle('hidden', gymEnabled);

  const badge = document.getElementById('gym-reminder-status');
  badge.textContent = Number(reminderInterval) > 0
    ? 'Напоминания: ' + reminderInterval + ' мин'
    : 'Напоминания: выкл';

  if (data.lastAiResult && data.lastAiResult.text && aiEnabled) {
    showAiResult(data.lastAiResult.title || 'Последний результат ИИ', data.lastAiResult.text);
  }
}

// =========================================================
// ЗАПУСК ПРИ ОТКРЫТИИ ОКНА И ОБРАБОТЧИКИ КНОПОК
// =========================================================

document.addEventListener('DOMContentLoaded', async () => {
  // Ставим индикатор на первую вкладку сразу при открытии
  const firstActiveTab = document.querySelector('.tab-btn.active');
  moveTabIndicator(firstActiveTab);

  // Переключение вкладок
  const tabButtons = document.querySelectorAll('.tab-btn');
  for (let i = 0; i < tabButtons.length; i++) {
    tabButtons[i].addEventListener('click', function () {
      switchTab(this.dataset.tab);
    });
  }

  // Проверяем активную вкладку на защищённый URL
  const tabs = await chrome.tabs.query({ active: true, currentWindow: true });
  activeTab = tabs[0] || null;
  isRestricted = isRestrictedUrl(activeTab ? activeTab.url : '');

  if (isRestricted) {
    document.getElementById('restricted-banner').classList.remove('hidden');
    setPageControlsDisabled(true);
  } else {
    const data = await chrome.storage.local.get('tabStates');
    const tabStates = data.tabStates || {};
    if (tabStates[activeTab.id]) {
      state = { ...DEFAULT_PAGE_STATE, ...tabStates[activeTab.id] };
    }
  }

  syncUiFromState();
  await loadAndRenderSettings();

  // Полный сброс адаптации страницы
  document.getElementById('btn-reset').addEventListener('click', async () => {
    if (isRestricted) return;
    state = { ...DEFAULT_PAGE_STATE };
    syncUiFromState();
    await runOnTab(resetAllPageAdaptations);
    await saveTabState();
  });

  // Общая функция обработки изменения ползунков
  function handleSliderChange(id, value) {
    const num = Number(value);
    if (id === 'slider-zoom') {
      state.zoom = num;
      document.getElementById('val-zoom').textContent = num + '%';
      runOnTab(applyZoomSetting, [num]);
      saveTabState();
    } else if (id === 'slider-space') {
      state.spacePercent = num;
      document.getElementById('val-space').textContent = num === 100 ? 'Норма' : num + '%';
      updateText();
    } else if (id === 'slider-contrast') {
      state.contrastValue = num;
      document.getElementById('val-contrast').textContent = num + '%';
      updateFilters();
    } else if (id === 'slider-brightness') {
      state.brightnessValue = num;
      document.getElementById('val-brightness').textContent = num + '%';
      updateFilters();
    } else if (id === 'slider-blur') {
      state.blurValue = num;
      document.getElementById('val-blur').textContent = num + ' px';
      updateFilters();
    }
  }

  const sliderIds = ['slider-zoom', 'slider-space', 'slider-contrast', 'slider-brightness', 'slider-blur'];
  for (let i = 0; i < sliderIds.length; i++) {
    const sliderId = sliderIds[i];
    document.getElementById(sliderId).addEventListener('input', function (e) {
      handleSliderChange(sliderId, e.target.value);
    });
  }

  // Кнопки "-" и "+" по краям ползунков
  const stepButtons = document.querySelectorAll('.step-btn');
  for (let i = 0; i < stepButtons.length; i++) {
    stepButtons[i].addEventListener('click', function () {
      const targetId = this.dataset.target;
      const step = Number(this.dataset.step);
      const slider = document.getElementById(targetId);
      const min = Number(slider.min);
      const max = Number(slider.max);
      let nextVal = Number(slider.value) + step;
      if (nextVal < min) nextVal = min;
      if (nextVal > max) nextVal = max;
      slider.value = nextVal;
      handleSliderChange(targetId, nextVal);
    });
  }

  // Кнопки вкладки «Текст»
  document.getElementById('btn-dys').addEventListener('click', () => {
    state.dyslexic = !state.dyslexic;
    setToggleButtonState('btn-dys', state.dyslexic);
    updateText();
  });

  document.getElementById('btn-links').addEventListener('click', () => {
    state.links = !state.links;
    setToggleButtonState('btn-links', state.links);
    runOnTab(toggleLinksHighlight, [state.links]);
    saveTabState();
  });

  document.getElementById('btn-cursor').addEventListener('click', () => {
    state.cursor = !state.cursor;
    setToggleButtonState('btn-cursor', state.cursor);
    runOnTab(toggleBigCursor, [state.cursor]);
    saveTabState();
  });

  document.getElementById('btn-audio').addEventListener('click', () => {
    state.audio = !state.audio;
    setToggleButtonState('btn-audio', state.audio);
    runOnTab(toggleAudioReader, [state.audio]);
    saveTabState();
  });

  // Кнопки вкладки «Экран»
  document.getElementById('btn-invert').addEventListener('click', () => {
    const active = !state.invert;
    resetColorFilters();
    state.invert = active;
    setToggleButtonState('btn-invert', state.invert);
    updateFilters();
  });

  document.getElementById('btn-night').addEventListener('click', () => {
    const active = !state.night;
    resetColorFilters();
    state.night = active;
    setToggleButtonState('btn-night', state.night);
    updateFilters();
  });

  const colorModes = ['prot', 'deut', 'trit'];
  for (let i = 0; i < colorModes.length; i++) {
    const mode = colorModes[i];
    document.getElementById('btn-' + mode).addEventListener('click', function () {
      const active = state.colorMode !== mode;
      resetColorFilters();
      if (active) {
        state.colorMode = mode;
        this.classList.add('active');
      }
      updateFilters();
    });
  }

  document.getElementById('btn-cataract').addEventListener('click', () => {
    state.cataract = !state.cataract;
    setToggleButtonState('btn-cataract', state.cataract);
    runOnTab(toggleCataractMode, [state.cataract]);
    saveTabState();
  });

  document.getElementById('btn-hideimg').addEventListener('click', () => {
    state.hideimg = !state.hideimg;
    setToggleButtonState('btn-hideimg', state.hideimg);
    runOnTab(toggleHideImages, [state.hideimg]);
    saveTabState();
  });

  // Кнопки вкладки «Здоровье и ИИ»
  document.getElementById('btn-ai-summary').addEventListener('click', summarizeSelectedText);
  document.getElementById('btn-ai-image').addEventListener('click', startImageDescriptionFlow);

  document.getElementById('btn-ai-speak').addEventListener('click', () => {
    if (!currentAiResultText || !('speechSynthesis' in window)) return;
    const speakBtn = document.getElementById('btn-ai-speak');
    if (window.speechSynthesis.speaking) {
      window.speechSynthesis.cancel();
      speakBtn.textContent = '🔊 Озвучить';
      return;
    }
    const ut = new SpeechSynthesisUtterance(currentAiResultText);
    ut.lang = 'ru-RU';
    ut.onend = () => {
      speakBtn.textContent = '🔊 Озвучить';
    };
    speakBtn.textContent = '⏹️ Стоп';
    window.speechSynthesis.speak(ut);
  });

  document.getElementById('btn-ai-copy').addEventListener('click', async () => {
    if (!currentAiResultText) return;
    await navigator.clipboard.writeText(currentAiResultText);
    const copyBtn = document.getElementById('btn-ai-copy');
    copyBtn.textContent = '✓ Скопировано';
    setTimeout(() => {
      copyBtn.textContent = '📋 Копировать';
    }, 1500);
  });

  document.getElementById('btn-ai-close').addEventListener('click', () => {
    if ('speechSynthesis' in window) window.speechSynthesis.cancel();
    document.getElementById('ai-result-card').classList.add('hidden');
  });

  document.getElementById('btn-gym').addEventListener('click', async () => {
    if (isRestricted || !activeTab || !activeTab.id) return;
    await chrome.scripting.executeScript({
      target: { tabId: activeTab.id },
      files: ['gym.js']
    });
    window.close();
  });

  // Быстрый переход к настройкам
  document.getElementById('btn-goto-settings-ai').addEventListener('click', () => switchTab('settings'));
  document.getElementById('btn-goto-settings-key').addEventListener('click', () => switchTab('settings'));
  document.getElementById('btn-goto-settings-gym').addEventListener('click', () => switchTab('settings'));

  // Вкладка «Настройки»
  document.getElementById('toggle-ai-enabled').addEventListener('change', async (e) => {
    await chrome.storage.local.set({ aiEnabled: e.target.checked });
    await loadAndRenderSettings();
  });

  document.getElementById('toggle-gym-enabled').addEventListener('change', async (e) => {
    await chrome.storage.local.set({ gymEnabled: e.target.checked });
    await chrome.runtime.sendMessage({ type: 'SYNC_ALARM' });
    await loadAndRenderSettings();
  });

  document.getElementById('select-ai-provider').addEventListener('change', async (e) => {
    await chrome.storage.local.set({ aiProvider: e.target.value });
    const status = document.getElementById('key-save-status');
    status.textContent = '✓ Нейросеть выбрана. Не забудьте указать ключ для неё.';
    status.classList.add('success');
  });

  document.getElementById('btn-toggle-key').addEventListener('click', () => {
    const input = document.getElementById('input-api-key');
    input.type = input.type === 'password' ? 'text' : 'password';
  });

  document.getElementById('btn-save-key').addEventListener('click', async () => {
    const apiKey = document.getElementById('input-api-key').value.trim();
    const aiProvider = document.getElementById('select-ai-provider').value;
    await chrome.storage.local.set({
      aiProvider: aiProvider,
      apiKey: apiKey,
      geminiApiKey: apiKey
    });
    const status = document.getElementById('key-save-status');
    status.textContent = apiKey ? '✓ API-ключ сохранён локально.' : 'API-ключ очищен.';
    status.classList.add('success');
    await loadAndRenderSettings();
  });

  document.getElementById('select-reminder').addEventListener('change', async (e) => {
    const val = e.target.value;
    const customWrap = document.getElementById('custom-interval-wrap');
    const status = document.getElementById('reminder-save-status');

    if (val === 'custom') {
      customWrap.classList.remove('hidden');
      return;
    }

    customWrap.classList.add('hidden');
    await chrome.storage.local.set({ reminderInterval: Number(val) });
    await chrome.runtime.sendMessage({ type: 'SYNC_ALARM' });
    status.textContent = Number(val) > 0 ? '✓ Напоминание каждые ' + val + ' мин.' : '✓ Напоминания отключены.';
    status.classList.add('success');
    await loadAndRenderSettings();
  });

  document.getElementById('btn-save-custom-minutes').addEventListener('click', async () => {
    const input = document.getElementById('input-custom-minutes');
    let minutes = parseInt(input.value, 10) || 25;
    if (minutes < 1) minutes = 1;
    if (minutes > 180) minutes = 180;
    input.value = minutes;

    await chrome.storage.local.set({
      reminderInterval: minutes,
      customMinutes: minutes
    });
    await chrome.runtime.sendMessage({ type: 'SYNC_ALARM' });

    const status = document.getElementById('reminder-save-status');
    status.textContent = '✓ Свой интервал установлен: каждые ' + minutes + ' мин.';
    status.classList.add('success');
    await loadAndRenderSettings();
  });
});