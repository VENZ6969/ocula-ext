(function () {
  // Если окно разминки уже открыто, повторно не запускаем
  if (document.getElementById('ocula-eye-gym')) return;

  // Список этапов разминки по Аветисову и правилу «20-20-20»
  const STAGES = [
    {
      title: 'Быстрое моргание (увлажнение)',
      instruction: 'Быстро и легко моргайте, не зажмуривая веки',
      voice: 'Начинаем разминку для глаз. Сядьте ровно. Быстро и легко поморгайте в течение десяти секунд.',
      duration: 10,
      mode: 'blink'
    },
    {
      title: 'Круговые движения (по методу Аветисова)',
      instruction: 'Плавно следите взглядом за точкой по кругу. Голова неподвижна.',
      voice: 'Упражнение по методу Аветисова. Плавно следите взглядом за точкой по кругу. Голова остаётся неподвижной.',
      duration: 12,
      mode: 'circle'
    },
    {
      title: 'Горизонтальная восьмёрка',
      instruction: 'Следите взглядом за плавной траекторией бесконечности',
      voice: 'Теперь следите за точкой, описывающей горизонтальную восьмёрку.',
      duration: 12,
      mode: 'eight'
    },
    {
      title: 'Диагонали',
      instruction: 'Плавно переводите взгляд из угла в угол вслед за точкой',
      voice: 'Переводите взгляд по диагоналям вслед за движущейся точкой.',
      duration: 12,
      mode: 'diagonal'
    },
    {
      title: 'Правило «20-20-20» (фокус вдаль)',
      instruction: 'Переведите взгляд от монитора в окно на объект примерно в 6 метрах от вас',
      voice: 'Правило двадцать-двадцать-двадцать. Отведите взгляд от экрана и посмотрите вдаль примерно на шесть метров в течение двадцати секунд.',
      duration: 20,
      mode: 'far'
    },
    {
      title: 'Расслабление век',
      instruction: 'Мягко закройте глаза, сделайте глубокий вдох и расслабьте веки',
      voice: 'Завершение разминки. Мягко закройте глаза на десять секунд, сделайте глубокий вдох и расслабьте мышцы вокруг глаз.',
      duration: 10,
      mode: 'relax'
    }
  ];

  // Создаём полноэкранный контейнер разминки
  const overlay = document.createElement('div');
  overlay.id = 'ocula-eye-gym';
  overlay.style.cssText = 'position:fixed;inset:0;background:rgba(11,15,25,0.97);z-index:2147483647;display:flex;flex-direction:column;align-items:center;justify-content:space-between;padding:28px 24px 36px;color:#f8fafc;font-family:-apple-system,BlinkMacSystemFont,"Segoe UI",Roboto,sans-serif;user-select:none;';

  overlay.innerHTML =
    '<div style="width:100%;max-width:760px;display:flex;justify-content:space-between;align-items:center;gap:12px;">' +
      '<div style="display:flex;align-items:center;gap:10px;">' +
        '<span style="background:#38bdf8;color:#082f49;font-weight:800;font-size:12px;padding:4px 10px;border-radius:999px;">OCULA РАЗМИНКА</span>' +
        '<span id="ocula-gym-step-badge" style="font-size:14px;color:#94a3b8;font-weight:700;">Этап 1 из ' + STAGES.length + '</span>' +
      '</div>' +
      '<div style="display:flex;gap:8px;">' +
        '<button id="ocula-gym-mute" style="background:#1b2438;color:#f8fafc;border:1px solid #334155;border-radius:8px;padding:8px 12px;font-size:13px;font-weight:700;cursor:pointer;">🔊 Голос вкл</button>' +
        '<button id="ocula-gym-next" style="background:#1b2438;color:#38bdf8;border:1px solid #38bdf8;border-radius:8px;padding:8px 12px;font-size:13px;font-weight:700;cursor:pointer;">⏭️ Далее</button>' +
        '<button id="ocula-gym-close" style="background:#1b2438;color:#f8fafc;border:1px solid #334155;border-radius:8px;padding:8px 14px;font-size:14px;font-weight:800;cursor:pointer;">✕ Закрыть</button>' +
      '</div>' +
    '</div>' +
    '<div style="text-align:center;max-width:620px;z-index:2;">' +
      '<div id="ocula-gym-title" style="font-size:26px;font-weight:800;margin-bottom:8px;letter-spacing:-0.4px;"></div>' +
      '<div id="ocula-gym-desc" style="font-size:16px;color:#cbd5e1;line-height:1.45;margin-bottom:16px;"></div>' +
      '<div id="ocula-gym-timer" style="display:inline-block;font-size:18px;font-weight:800;color:#38bdf8;background:rgba(56,189,248,0.12);border:1px solid rgba(56,189,248,0.35);padding:6px 18px;border-radius:999px;"></div>' +
    '</div>' +
    '<div id="ocula-gym-stage-area" style="position:relative;width:100%;max-width:720px;height:320px;display:flex;align-items:center;justify-content:center;">' +
      '<div id="ocula-gym-center-card" style="display:none;text-align:center;padding:24px 32px;border-radius:20px;background:#131a2a;border:2px solid #38bdf8;max-width:420px;">' +
        '<div id="ocula-gym-center-icon" style="font-size:48px;margin-bottom:10px;"></div>' +
        '<div id="ocula-gym-center-text" style="font-size:17px;font-weight:700;color:#f8fafc;"></div>' +
      '</div>' +
      '<div id="ocula-gym-dot" style="position:absolute;width:28px;height:28px;border-radius:50%;background:#38bdf8;box-shadow:0 0 28px #38bdf8,0 0 8px #ffffff;display:none;"></div>' +
    '</div>' +
    '<div style="width:100%;max-width:760px;">' +
      '<div style="height:8px;width:100%;background:#1b2438;border-radius:999px;overflow:hidden;">' +
        '<div id="ocula-gym-progress" style="height:100%;width:0%;background:#38bdf8;transition:width 0.3s ease;"></div>' +
      '</div>' +
    '</div>';

  document.body.appendChild(overlay);

  const stepBadge = overlay.querySelector('#ocula-gym-step-badge');
  const titleEl = overlay.querySelector('#ocula-gym-title');
  const descEl = overlay.querySelector('#ocula-gym-desc');
  const timerEl = overlay.querySelector('#ocula-gym-timer');
  const stageArea = overlay.querySelector('#ocula-gym-stage-area');
  const dot = overlay.querySelector('#ocula-gym-dot');
  const centerCard = overlay.querySelector('#ocula-gym-center-card');
  const centerIcon = overlay.querySelector('#ocula-gym-center-icon');
  const centerText = overlay.querySelector('#ocula-gym-center-text');
  const progressBar = overlay.querySelector('#ocula-gym-progress');
  const muteBtn = overlay.querySelector('#ocula-gym-mute');
  const nextBtn = overlay.querySelector('#ocula-gym-next');
  const closeBtn = overlay.querySelector('#ocula-gym-close');

  let stageIndex = 0;
  let secondsLeft = 0;
  let isMuted = false;
  let tick = 0;
  let animId = null;
  let secondTimer = null;

  // Голосовая подсказка для текущего упражнения
  function speak(text) {
    if (isMuted || !('speechSynthesis' in window)) return;
    window.speechSynthesis.cancel();
    const ut = new SpeechSynthesisUtterance(text);
    ut.lang = 'ru-RU';
    ut.rate = 0.96;
    window.speechSynthesis.speak(ut);
  }

  // Полное закрытие разминки и остановка таймеров
  function finishGym() {
    cancelAnimationFrame(animId);
    clearInterval(secondTimer);
    document.removeEventListener('keydown', onKeyDown);
    if ('speechSynthesis' in window) window.speechSynthesis.cancel();
    overlay.remove();
  }

  function onKeyDown(e) {
    if (e.key === 'Escape') finishGym();
  }
  document.addEventListener('keydown', onKeyDown);

  muteBtn.addEventListener('click', () => {
    isMuted = !isMuted;
    muteBtn.textContent = isMuted ? '🔇 Без звука' : '🔊 Голос вкл';
    if (isMuted && 'speechSynthesis' in window) {
      window.speechSynthesis.cancel();
    }
  });

  closeBtn.addEventListener('click', finishGym);

  nextBtn.addEventListener('click', () => {
    goToStage(stageIndex + 1);
  });

  // Плавная анимация движения точки (замедлена примерно в 2.5 раза для комфорта глаз)
  function animateStage() {
    const stage = STAGES[stageIndex];
    if (!stage) return;

    const areaRect = stageArea.getBoundingClientRect();
    const cx = areaRect.width / 2;
    const cy = areaRect.height / 2;
    const rx = Math.min(280, areaRect.width * 0.4);
    const ry = Math.min(125, areaRect.height * 0.38);

    // Медленный комфортный шаг
    tick += 0.012;

    if (stage.mode === 'circle') {
      const dir = secondsLeft > stage.duration / 2 ? 1 : -1;
      const angle = tick * 1.4 * dir;
      const x = cx + Math.cos(angle) * rx * 0.65;
      const y = cy + Math.sin(angle) * ry;
      dot.style.left = (x - 14) + 'px';
      dot.style.top = (y - 14) + 'px';
    } else if (stage.mode === 'eight') {
      const scale = 2 / (3 - Math.cos(2 * tick));
      const x = cx + scale * Math.cos(tick) * rx * 0.9;
      const y = cy + scale * Math.sin(2 * tick) * ry * 0.85;
      dot.style.left = (x - 14) + 'px';
      dot.style.top = (y - 14) + 'px';
    } else if (stage.mode === 'diagonal') {
      const phase = (tick * 0.55) % 2;
      let progress;
      let x;
      let y;
      if (phase < 1) {
        progress = Math.sin(phase * Math.PI - Math.PI / 2) * 0.5 + 0.5;
        x = cx - rx + progress * (rx * 2);
        y = cy - ry + progress * (ry * 2);
      } else {
        progress = Math.sin((phase - 1) * Math.PI - Math.PI / 2) * 0.5 + 0.5;
        x = cx + rx - progress * (rx * 2);
        y = cy - ry + progress * (ry * 2);
      }
      dot.style.left = (x - 14) + 'px';
      dot.style.top = (y - 14) + 'px';
    } else if (stage.mode === 'blink') {
      const pulse = 22 + Math.abs(Math.sin(tick * 2.5)) * 12;
      dot.style.width = pulse + 'px';
      dot.style.height = pulse + 'px';
      dot.style.left = (cx - pulse / 2) + 'px';
      dot.style.top = (cy - pulse / 2) + 'px';
    }

    animId = requestAnimationFrame(animateStage);
  }

  // Переключение на нужный этап разминки
  function goToStage(index) {
    clearInterval(secondTimer);
    cancelAnimationFrame(animId);

    if (index >= STAGES.length) {
      speak('Разминка успешно завершена! Берегите зрение.');
      titleEl.textContent = 'Разминка завершена!';
      descEl.textContent = 'Вы отлично позаботились о своих глазах. Можно возвращаться к работе.';
      timerEl.textContent = 'Готово';
      dot.style.display = 'none';
      centerCard.style.display = 'block';
      centerIcon.textContent = '✅';
      centerText.textContent = 'Окно закроется автоматически...';
      progressBar.style.width = '100%';
      setTimeout(finishGym, 2500);
      return;
    }

    stageIndex = index;
    const stage = STAGES[stageIndex];
    secondsLeft = stage.duration;
    tick = 0;

    stepBadge.textContent = 'Этап ' + (stageIndex + 1) + ' из ' + STAGES.length;
    titleEl.textContent = stage.title;
    descEl.textContent = stage.instruction;
    timerEl.textContent = 'Осталось: ' + secondsLeft + ' сек';
    progressBar.style.width = Math.round((stageIndex / STAGES.length) * 100) + '%';

    dot.style.width = '28px';
    dot.style.height = '28px';

    if (stage.mode === 'far') {
      dot.style.display = 'none';
      centerCard.style.display = 'block';
      centerIcon.textContent = '🪟';
      centerText.textContent = 'Смотрите на удалённый объект (~6 м)';
    } else if (stage.mode === 'relax') {
      dot.style.display = 'none';
      centerCard.style.display = 'block';
      centerIcon.textContent = '😌';
      centerText.textContent = 'Закройте глаза и расслабьте веки';
    } else {
      centerCard.style.display = 'none';
      dot.style.display = 'block';
      animId = requestAnimationFrame(animateStage);
    }

    speak(stage.voice);

    secondTimer = setInterval(() => {
      secondsLeft = secondsLeft - 1;
      timerEl.textContent = 'Осталось: ' + secondsLeft + ' сек';
      if (secondsLeft <= 0) {
        goToStage(stageIndex + 1);
      }
    }, 1000);
  }

  goToStage(0);
})();